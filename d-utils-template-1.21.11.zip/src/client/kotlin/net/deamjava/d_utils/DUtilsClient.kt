package net.deamjava.d_utils

import net.fabricmc.api.ClientModInitializer

object DUtilsClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}